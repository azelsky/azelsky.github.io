## Please read Slackie's [Contributing Guidelines](http://www.slackie.nielsklom.eu/contribute.php).
